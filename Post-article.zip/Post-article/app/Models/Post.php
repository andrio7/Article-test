<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
    use HasFactory;

    protected $guarded =['id'];

    protected $with = ['author','category'];

    public function Category()
    {
        return $this->belongsTo(Category::class);
    }


    public function author()
    {
        // mengembalikan relasi dr model post ke category
        // kita ingin 1 postingan memiliki 1 category
        // one to one menggunkan belongsTo
        // One to many menggunakan hasMany
        // ditambahkan user_id agar jelas author ini kemana agar tidak error
        return $this->belongsTo(User::class, 'user_id');
    }


    // agar otomatis mencari slug bukan id
    public function getRouteKeyName()
    {
        return 'slug';
    }


    // agar slug otomatis dituliskan
    public function sluggable(): array
    {
        return [
            'slug' => [
                'source' => 'title'
            ]
        ];
    }
}