<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DashboardPostController;
use App\Http\Controllers\PostController;
use App\Models\Post;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


// dashboard
Route::get('/', function(){
    return view('index' , [
        'title' => 'in dashboard'
    ]);
});
Route::get('/post', function () {
    // $blog_posts =

    return view('post', [
        "title" => "All Posts",
        "posts" =>  Post::latest()->paginate(5)
    ]);
 });



// dasboard controller
Route::resource('/posts', DashboardPostController::class);