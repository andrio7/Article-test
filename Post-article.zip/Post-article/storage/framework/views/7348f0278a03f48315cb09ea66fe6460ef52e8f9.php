

<?php $__env->startSection('container'); ?>

<h1 class="text-center mb-3"> <?php echo e($title); ?></h1>

<?php if($posts->count()): ?>
<div class="card mb-3">
    <img src="https://source.unsplash.com/1200x400?<?php echo e($posts[0]->category->name); ?>" class="card-img-top" alt="<?php echo e($posts[0]->category->name); ?>">   
    <div class="card-body text-center">
        
      <h3 class="card-title"><a href="/posts/<?php echo e($posts[0]->slug); ?>" class="text-decoration-none text-dark"><?php echo e($posts[0]->title); ?></a></h3>
      
        <P>
            <small class="text-muted">
            <a href="/posts?category=<?php echo e($posts[0]->category->slug); ?>" class="text-decoration-none"><?php echo e($posts[0]->category->name); ?> </a> <?php echo e($posts[0]->created_at->diffForHumans()); ?>

            </small>
        </P>
    
        <p class="card-text"><?php echo e($posts[0]->excerpt); ?></p>

        <a href="/posts/<?php echo e($posts[0]->slug); ?>" class="text-decoration-none btn btn-primary">Read More</a>

    </div>
</div>



<div class="container">
    <div class="row">

        <?php $__currentLoopData = $posts->skip(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            
        <div class="col-lg-4 col-md-6 col-sm-12 mb-3">
            <div class="card" >
                <div class="position-absolute px-3 py-2 " style="background-color: rgba(0, 0, 0, 0.7)"><a href="/posts?category=" class="text-white text-decoration-none"><?php echo e($post->category->name); ?></a></div>
                <img src="https://source.unsplash.com/500x400?<?php echo e($post->category->name); ?>" class="card-img-top" alt="<?php echo e($post->category->name); ?>">
                <div class="card-body">
                  <h5 class="card-title"><?php echo e($post->title); ?></h5>
                  <P>
                </P>
                  <p class="card-text"><?php echo e($post->excerpt); ?></p>
                  <a href="/posts/<?php echo e($post->slug); ?>" class="btn btn-primary">Read More</a>
                </div>
              </div>   
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<?php else: ?> 
<p class="text-center fs-4">NO POST FOUND.</p>

<?php endif; ?>


<div class="d-flex justify-content-end">
    <?php echo e($posts->links()); ?>

</div>


<?php $__env->stopSection(); ?>


<?php /**PATH E:\Penting\belajar web design\web_laravel\Post-article\resources\views/posts.blade.php ENDPATH**/ ?>